#include "G4RunManager.hh"
#include "G4UImanager.hh"
#include "G4VisExecutive.hh"
#include "G4UIExecutive.hh"
#include "DetectorConstruction.hh"
#include "PhysicsList.hh"
#include "ActionInitialization.hh"

int main(int argc, char** argv)
{
    // Создаем RunManager
    G4RunManager* runManager = new G4RunManager;

    // Инициализация
    DetectorConstruction* detector = new DetectorConstruction();
    runManager->SetUserInitialization(detector);
    runManager->SetUserInitialization(new PhysicsList());
    runManager->SetUserInitialization(new ActionInitialization(detector));
    
    // Инициализация ядра
    runManager->Initialize();

    // Настройка визуализации
    G4VisManager* visManager = new G4VisExecutive;
    visManager->Initialize();

    G4UImanager* UImanager = G4UImanager::GetUIpointer();
    
    // Базовые настройки визуализации
    UImanager->ApplyCommand("/vis/scene/create");
    UImanager->ApplyCommand("/vis/open OGL 800x800-0+0");
    UImanager->ApplyCommand("/vis/viewer/set/viewpointThetaPhi 60 30");
    UImanager->ApplyCommand("/vis/viewer/set/style surface");
    UImanager->ApplyCommand("/vis/viewer/set/auxiliaryEdge true");
    UImanager->ApplyCommand("/vis/viewer/set/lineSegmentsPerCircle 100");
    UImanager->ApplyCommand("/vis/scene/add/trajectories smooth");
    UImanager->ApplyCommand("/vis/scene/add/axes 0 0 0 100 mm");
    UImanager->ApplyCommand("/vis/scene/endOfEventAction accumulate");
    UImanager->ApplyCommand("/vis/viewer/set/background white");
    UImanager->ApplyCommand("/vis/geometry/set/forceSolid all");
    UImanager->ApplyCommand("/vis/geometry/set/forceWireframe Housing 1");

    // UI сессия
    if (argc == 1) {
        G4UIExecutive* ui = new G4UIExecutive(argc, argv);
        UImanager->ApplyCommand("/vis/viewer/zoom 1.5");
        UImanager->ApplyCommand("/vis/viewer/set/projection perspective");
        ui->SessionStart();
        delete ui;
    } else {
        G4String command = "/control/execute ";
        G4String fileName = argv[1];
        UImanager->ApplyCommand(command + fileName);
    }

    // Очистка
    delete visManager;
    delete runManager;
    return 0;
}
