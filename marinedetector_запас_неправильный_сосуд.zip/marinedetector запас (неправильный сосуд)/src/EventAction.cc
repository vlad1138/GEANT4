#include "EventAction.hh"
#include "RunAction.hh"
#include "G4Event.hh"
#include "G4AnalysisManager.hh"
#include "G4SystemOfUnits.hh"

EventAction::EventAction(RunAction* runAction)
: G4UserEventAction(),
  fRunAction(runAction),
  fEventEnergy(0.) {}  // Явная инициализация

EventAction::~EventAction() {}

void EventAction::BeginOfEventAction(const G4Event*) {
    fEventEnergy = 0.;  // Сброс энергии в начале события
}

void EventAction::EndOfEventAction(const G4Event*) {
    if (fEventEnergy > 0.) {
        fRunAction->AddEnergyDeposit(fEventEnergy);
        
        auto analysisManager = G4AnalysisManager::Instance();
        analysisManager->FillH1(0, fEventEnergy/keV);
    }
}

void EventAction::AddEnergyDeposit(G4double edep) {
    fEventEnergy += edep;
}
