#include "RunAction.hh"
#include "G4Run.hh"
#include "G4UnitsTable.hh"
#include "G4SystemOfUnits.hh"
#include "G4AnalysisManager.hh"
#include <fstream>
#include <iostream>

RunAction::RunAction()
: G4UserRunAction() {
    auto analysisManager = G4AnalysisManager::Instance();
    
    if (!analysisManager) {
        G4ExceptionDescription msg;
        msg << "Не удалось создать анализ manager";
        G4Exception("RunAction::RunAction()",
                   "Analysis_F000", FatalException, msg);
    }
    
    analysisManager->SetVerboseLevel(1);
    analysisManager->SetDefaultFileType("root");
    analysisManager->CreateH1("EnergyDeposit", "Energy deposition in detector", 1000, 0., 3000., "keV");
    
    // Инициализация атомарных переменных
    fTotalEnergyDeposit = 0.;
    fNumEvents = 0;
}

RunAction::~RunAction() {
    auto analysisManager = G4AnalysisManager::Instance();
    if (analysisManager) {
        analysisManager->Write();
        analysisManager->CloseFile();
    }
}

void RunAction::BeginOfRunAction(const G4Run* run) {
    std::lock_guard<std::mutex> lock(fMutex);
    fEnergyDeposits.clear();
    fTotalEnergyDeposit = 0.;
    fNumEvents = 0;
    
    auto analysisManager = G4AnalysisManager::Instance();
    if (analysisManager) {
        G4String fileName = "analysis_" + std::to_string(run->GetRunID()) + ".root";
        analysisManager->OpenFile(fileName);
    }
    
    G4cout << "### Run " << run->GetRunID() << " started." << G4endl;
}

void RunAction::EndOfRunAction(const G4Run* run) {
    std::lock_guard<std::mutex> lock(fMutex);
    
    std::ofstream spectrumFile("spectrum_" + std::to_string(run->GetRunID()) + ".dat");
    if (spectrumFile.is_open()) {
        for (G4double edep : fEnergyDeposits) {
            spectrumFile << edep/keV << "\n";
        }
        spectrumFile.close();
    }
    
    G4int numDetected = fEnergyDeposits.size();
    G4int totalEvents = run->GetNumberOfEvent();
    G4double efficiency = totalEvents > 0 ? (G4double)numDetected / totalEvents : 0.;
    
    std::ofstream effFile("efficiency_" + std::to_string(run->GetRunID()) + ".txt");
    if (effFile.is_open()) {
        effFile << "Volume registration efficiency: " << efficiency*100 << "%\n"
                << "Total events: " << totalEvents << "\n"
                << "Detected events: " << numDetected << "\n"
                << "Total energy deposited: " << fTotalEnergyDeposit/keV << " keV\n";
        effFile.close();
    }
    
    G4cout << "\n--- Run summary ---\n"
           << " Events processed: " << totalEvents << "\n"
           << " Detected events: " << numDetected << "\n"
           << " Efficiency: " << efficiency*100 << "%\n"
           << " Total energy: " << G4BestUnit(fTotalEnergyDeposit, "Energy") << G4endl;
}

void RunAction::AddEnergyDeposit(G4double edep) {
    std::lock_guard<std::mutex> lock(fMutex);
    
    fEnergyDeposits.push_back(edep);
    fTotalEnergyDeposit = fTotalEnergyDeposit.load() + edep;
    fNumEvents++;
    
    auto analysisManager = G4AnalysisManager::Instance();
    if (analysisManager) {
        analysisManager->FillH1(0, edep/keV);
    }
}
