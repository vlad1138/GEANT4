#include "DetectorConstruction.hh"
#include "G4NistManager.hh"
#include "G4Box.hh"
#include "G4Tubs.hh"
#include "G4Cons.hh"
#include "G4LogicalVolume.hh"
#include "G4PVPlacement.hh"
#include "G4SystemOfUnits.hh"
#include "G4VisAttributes.hh"
#include "G4SubtractionSolid.hh"
#include "G4UnionSolid.hh"
#include "G4SDManager.hh"
#include "G4Colour.hh"
#include "SensitiveDetector.hh"

DetectorConstruction::DetectorConstruction() 
: G4VUserDetectorConstruction(),
  fLogicWorld(nullptr), fLogicCrystal(nullptr), fLogicDeadLayer(nullptr),
  fLogicContact(nullptr), fLogicWindow(nullptr), fLogicVacuumGap(nullptr),
  fLogicHousing(nullptr), fLogicColdFinger(nullptr), fLogicMountingFlange(nullptr),
  fLogicEndCap(nullptr), fLogicMarinelli(nullptr), fLogicDetectorHousing(nullptr),
  fLogicWater(nullptr), fMarinelliWellTopZ(0), fMarinelliWellBottomZ(0),
  fMarinelliWaterTopZ(0), fWindowPositionZ(0)
{
    DefineMaterials();
}

DetectorConstruction::~DetectorConstruction()
{
}

void DetectorConstruction::DefineMaterials()
{
    G4NistManager* nist = G4NistManager::Instance();
    
    fAir = nist->FindOrBuildMaterial("G4_AIR");
    fVacuum = nist->FindOrBuildMaterial("G4_Galactic");
    fWater = nist->FindOrBuildMaterial("G4_WATER");
    fGermanium = nist->FindOrBuildMaterial("G4_Ge");
    fAluminum = nist->FindOrBuildMaterial("G4_Al");
    fBeryllium = nist->FindOrBuildMaterial("G4_Be");
    fCopper = nist->FindOrBuildMaterial("G4_Cu");
    fPlastic = nist->FindOrBuildMaterial("G4_PLEXIGLASS");
    fStainlessSteel = nist->FindOrBuildMaterial("G4_STAINLESS-STEEL");
    
    fKapton = new G4Material("Kapton", 1.42*g/cm3, 3);
    fKapton->AddElement(nist->FindOrBuildElement("C"), 22);
    fKapton->AddElement(nist->FindOrBuildElement("H"), 10);
    fKapton->AddElement(nist->FindOrBuildElement("O"), 5);
    
    fTeflon = new G4Material("Teflon", 2.2*g/cm3, 2);
    fTeflon->AddElement(nist->FindOrBuildElement("C"), 2);
    fTeflon->AddElement(nist->FindOrBuildElement("F"), 4);
}

void DetectorConstruction::ConstructGermaniumDetector()
{
    // ORTEC GEM60-P4 параметры
    G4double crystalDiam = 60.5*mm;
    G4double crystalHeight = 54.5*mm;
    G4double holeDiam = 10.0*mm;
    G4double holeDepth = 42.0*mm;
    G4double deadLayerThickness = 0.7*mm;
    G4double contactThickness = 0.1*mm;
    G4double windowThickness = 0.5*mm;
    G4double vacuumGap = 1.0*mm;
    G4double housingThickness = 3.0*mm;
    G4double housingLength = 80.0*mm;
    G4double coldFingerDiam = 8.0*mm;
    G4double coldFingerLength = 30.0*mm;
    G4double endCapThickness = 1.5*mm;
    G4double flangeThickness = 5.0*mm;
    G4double flangeDiam = 76.0*mm;

    // Germanium crystal with hole
    G4Tubs* solidCrystalOuter = new G4Tubs("CrystalOuter", 0, crystalDiam/2, crystalHeight/2, 0, 360*deg);
    G4Tubs* solidHole = new G4Tubs("Hole", 0, holeDiam/2, holeDepth/2, 0, 360*deg);
    G4SubtractionSolid* solidCrystal = new G4SubtractionSolid("Crystal", solidCrystalOuter, solidHole,
                                                            0, G4ThreeVector(0,0,crystalHeight/2-holeDepth/2));
    fLogicCrystal = new G4LogicalVolume(solidCrystal, fGermanium, "Crystal");

    // Dead layer (outer surface)
    G4Tubs* solidDeadLayer = new G4Tubs("DeadLayer", 
                                      crystalDiam/2 - deadLayerThickness, 
                                      crystalDiam/2, 
                                      crystalHeight/2, 
                                      0, 360*deg);
    fLogicDeadLayer = new G4LogicalVolume(solidDeadLayer, fGermanium, "DeadLayer");

    // Electrical contact (outer surface)
    G4Tubs* solidContact = new G4Tubs("Contact", 
                                    crystalDiam/2, 
                                    crystalDiam/2 + contactThickness, 
                                    crystalHeight/2, 
                                    0, 360*deg);
    fLogicContact = new G4LogicalVolume(solidContact, fAluminum, "Contact");

    // Vacuum gap
    G4Tubs* solidVacuumGap = new G4Tubs("VacuumGap", 
                                      crystalDiam/2 + contactThickness, 
                                      crystalDiam/2 + contactThickness + vacuumGap, 
                                      crystalHeight/2, 
                                      0, 360*deg);
    fLogicVacuumGap = new G4LogicalVolume(solidVacuumGap, fVacuum, "VacuumGap");

    // Aluminum housing
    G4Tubs* solidHousing = new G4Tubs("Housing", 
                                    0, 
                                    crystalDiam/2 + contactThickness + vacuumGap + housingThickness, 
                                    housingLength/2, 
                                    0, 360*deg);
    fLogicHousing = new G4LogicalVolume(solidHousing, fAluminum, "Housing");

    // Cold finger (copper)
    G4Tubs* solidColdFinger = new G4Tubs("ColdFinger", 0, coldFingerDiam/2, coldFingerLength/2, 0, 360*deg);
    fLogicColdFinger = new G4LogicalVolume(solidColdFinger, fCopper, "ColdFinger");

    // Mounting flange (stainless steel)
    G4Tubs* solidFlange = new G4Tubs("Flange", 0, flangeDiam/2, flangeThickness/2, 0, 360*deg);
    fLogicMountingFlange = new G4LogicalVolume(solidFlange, fStainlessSteel, "Flange");

    // End cap with Be window
    G4Tubs* solidEndCap = new G4Tubs("EndCap", 
                                   0, 
                                   crystalDiam/2 + contactThickness + vacuumGap + housingThickness, 
                                   endCapThickness/2, 
                                   0, 360*deg);
    G4Tubs* solidWindow = new G4Tubs("Window", 0, crystalDiam/2, windowThickness/2, 0, 360*deg);
    G4SubtractionSolid* solidEndCapWithWindow = new G4SubtractionSolid("EndCapWithWindow", solidEndCap, solidWindow,
                                                                     0, G4ThreeVector(0,0,-endCapThickness/2+windowThickness/2));
    fLogicEndCap = new G4LogicalVolume(solidEndCapWithWindow, fAluminum, "EndCap");
    fLogicWindow = new G4LogicalVolume(solidWindow, fBeryllium, "Window");

    // Assembly
    G4double zPos = -housingLength/2 + endCapThickness/2;
    new G4PVPlacement(0, G4ThreeVector(0,0,zPos), fLogicEndCap, "EndCap", fLogicHousing, false, 0);
    
    zPos += endCapThickness/2 + windowThickness/2;
    new G4PVPlacement(0, G4ThreeVector(0,0,zPos), fLogicWindow, "Window", fLogicHousing, false, 0);
    
    zPos += windowThickness/2 + crystalHeight/2;
    new G4PVPlacement(0, G4ThreeVector(0,0,zPos), fLogicCrystal, "Crystal", fLogicHousing, false, 0);
    new G4PVPlacement(0, G4ThreeVector(0,0,zPos), fLogicDeadLayer, "DeadLayer", fLogicHousing, false, 1);
    new G4PVPlacement(0, G4ThreeVector(0,0,zPos), fLogicContact, "Contact", fLogicHousing, false, 2);
    new G4PVPlacement(0, G4ThreeVector(0,0,zPos), fLogicVacuumGap, "VacuumGap", fLogicHousing, false, 3);
    
    zPos = housingLength/2 - coldFingerLength/2;
    new G4PVPlacement(0, G4ThreeVector(0,0,zPos), fLogicColdFinger, "ColdFinger", fLogicHousing, false, 0);
    
    zPos = housingLength/2 + flangeThickness/2;
    new G4PVPlacement(0, G4ThreeVector(0,0,zPos), fLogicMountingFlange, "Flange", fLogicHousing, false, 0);

    // Запоминаем позицию окна детектора
    fWindowPositionZ = zPos - flangeThickness/2 - housingLength/2 + endCapThickness + windowThickness;
}

void DetectorConstruction::ConstructMarinelliBeaker()
{
    // Параметры сосуда Маринелли
    G4double outerRadius = 170.0/2*mm;
    G4double totalHeight = 130.0*mm;
    G4double wallThickness = 3.0*mm;
    G4double wellRadius = 84.0/2*mm;
    G4double wellDepth = 71.0*mm;
    G4double lidThickness = 3.0*mm;

    // Основной корпус сосуда (без крышки)
    G4Tubs* solidOuter = new G4Tubs("BeakerOuter", 
                                   0, outerRadius, 
                                   (totalHeight-lidThickness)/2, 
                                   0, 360*deg);

    // Внутренняя полость для воды (без колодца)
    G4Tubs* solidWaterCavity = new G4Tubs("WaterCavity", 
                                        0, outerRadius-wallThickness, 
                                        (totalHeight-lidThickness-wallThickness)/2, 
                                        0, 360*deg);

    // Колодец для детектора (воздух)
    G4Tubs* solidWell = new G4Tubs("Well", 
                                0, wellRadius, 
                                wellDepth/2, 
                                0, 360*deg);

    // Крышка (без отверстия)
    G4Tubs* solidLid = new G4Tubs("Lid", 
                               0, outerRadius, 
                               lidThickness/2, 
                               0, 360*deg);

    // Собираем основной корпус с крышкой
    G4UnionSolid* solidBeaker = new G4UnionSolid(
        "Beaker", solidOuter, solidLid,
        0, G4ThreeVector(0,0,(totalHeight-lidThickness)/2 + lidThickness/2));

    // Создаем логический объем для пластикового корпуса
    fLogicMarinelli = new G4LogicalVolume(solidBeaker, fPlastic, "MarinelliBeaker");

    // Создаем объем воды (вычитаем колодец)
    G4SubtractionSolid* solidWater = new G4SubtractionSolid(
        "Water", solidWaterCavity, solidWell,
        0, G4ThreeVector(0,0,-(totalHeight-lidThickness-wallThickness)/2 + wellDepth/2));

    fLogicWater = new G4LogicalVolume(solidWater, fWater, "MarinelliWater");

    // Создаем объем воздуха в колодце
    G4LogicalVolume* logicWell = new G4LogicalVolume(solidWell, fAir, "MarinelliWell");

    // Запоминаем ключевые координаты
    fMarinelliWellTopZ = (totalHeight-lidThickness-wallThickness)/2 - wellDepth/2;
    fMarinelliWellBottomZ = -(totalHeight-lidThickness-wallThickness)/2 + wellDepth/2;
    fMarinelliWaterTopZ = (totalHeight-lidThickness-wallThickness)/2;

    // Размещаем воду и воздух внутри сосуда
    new G4PVPlacement(0, G4ThreeVector(0,0,0), fLogicWater, "MarinelliWater", 
                     fLogicMarinelli, false, 0);
    
    new G4PVPlacement(0, G4ThreeVector(0,0,fMarinelliWellTopZ), 
                     logicWell, "MarinelliWell", fLogicMarinelli, false, 0);
}

G4VPhysicalVolume* DetectorConstruction::Construct()
{
    // World volume
    G4Box* solidWorld = new G4Box("World", 1*m, 1*m, 1*m);
    fLogicWorld = new G4LogicalVolume(solidWorld, fAir, "World");
    G4PVPlacement* physWorld = new G4PVPlacement(0, G4ThreeVector(), fLogicWorld, "World", 0, false, 0);

    // Construct detector and beaker
    ConstructGermaniumDetector();
    ConstructMarinelliBeaker();

    // Позиционируем сосуд Маринелли
    G4double marinelliPosZ = 0;
    new G4PVPlacement(0, G4ThreeVector(0,0,marinelliPosZ), 
                     fLogicMarinelli, "MarinelliBeaker", fLogicWorld, false, 0);

    // Позиционируем детектор так, чтобы входное окно было на 5 мм выше дна колодца
    G4double windowToWellBottomGap = 5*mm;
    G4double wellDepth = fMarinelliWellBottomZ - fMarinelliWellTopZ;
    G4double detectorPosZ = marinelliPosZ + fMarinelliWellTopZ + wellDepth/2 - fWindowPositionZ + windowToWellBottomGap;
    
    new G4PVPlacement(0, G4ThreeVector(0,0,detectorPosZ), 
                     fLogicHousing, "Detector", fLogicWorld, false, 0);

    SetVisualAttributes();
    return physWorld;
}

void DetectorConstruction::ConstructSDandField()
{
    G4SDManager* SDman = G4SDManager::GetSDMpointer();
    G4String SDname = "GermaniumSD";
    SensitiveDetector* germaniumSD = new SensitiveDetector(SDname);
    SDman->AddNewDetector(germaniumSD);
    fLogicCrystal->SetSensitiveDetector(germaniumSD);
}

void DetectorConstruction::SetVisualAttributes()
{
    G4VisAttributes* visAttr;
    
    // Germanium crystal (полупрозрачный серый)
    visAttr = new G4VisAttributes(G4Colour(0.7, 0.7, 0.7, 0.7));
    visAttr->SetForceSolid(true);
    fLogicCrystal->SetVisAttributes(visAttr);
    
    // Dead layer (красный, полупрозрачный)
    visAttr = new G4VisAttributes(G4Colour(1.0, 0.0, 0.0, 0.3));
    visAttr->SetForceSolid(true);
    fLogicDeadLayer->SetVisAttributes(visAttr);
    
    // Contact (металлик)
    visAttr = new G4VisAttributes(G4Colour(0.9, 0.9, 0.9));
    visAttr->SetForceSolid(true);
    fLogicContact->SetVisAttributes(visAttr);
    
    // Vacuum gap (невидимый)
    visAttr = new G4VisAttributes(G4Colour(0,0,0,0));
    visAttr->SetVisibility(false);
    fLogicVacuumGap->SetVisAttributes(visAttr);
    
    // Housing (только каркас)
    visAttr = new G4VisAttributes(G4Colour(0.8, 0.8, 0.8));
    visAttr->SetForceWireframe(true);
    fLogicHousing->SetVisAttributes(visAttr);
    
    // Cold finger (медный)
    visAttr = new G4VisAttributes(G4Colour(0.8, 0.5, 0.2));
    visAttr->SetForceSolid(true);
    fLogicColdFinger->SetVisAttributes(visAttr);
    
    // Be window (зеленый, полупрозрачный)
    visAttr = new G4VisAttributes(G4Colour(0.0, 1.0, 0.0, 0.7));
    visAttr->SetForceSolid(true);
    fLogicWindow->SetVisAttributes(visAttr);
    
    // Marinelli beaker (синий пластик, полупрозрачный)
    visAttr = new G4VisAttributes(G4Colour(0.0, 0.5, 1.0, 0.5));
    visAttr->SetForceSolid(true);
    fLogicMarinelli->SetVisAttributes(visAttr);
    
    // Water (голубая, полупрозрачная)
    visAttr = new G4VisAttributes(G4Colour(0.0, 0.8, 1.0, 0.4));
    visAttr->SetForceSolid(true);
    fLogicWater->SetVisAttributes(visAttr);
    
    // Mounting flange (стальной)
    visAttr = new G4VisAttributes(G4Colour(0.5, 0.5, 0.5));
    visAttr->SetForceSolid(true);
    fLogicMountingFlange->SetVisAttributes(visAttr);
}
