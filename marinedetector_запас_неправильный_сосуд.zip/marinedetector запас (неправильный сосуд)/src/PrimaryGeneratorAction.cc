#include "PrimaryGeneratorAction.hh"
#include "DetectorConstruction.hh"
#include "G4Event.hh"
#include "G4ParticleTable.hh"
#include "G4ParticleDefinition.hh"
#include "G4SystemOfUnits.hh"
#include "Randomize.hh"
#include "G4PhysicalConstants.hh"
#include "G4Tubs.hh"

PrimaryGeneratorAction::PrimaryGeneratorAction(DetectorConstruction* detCon)
: G4VUserPrimaryGeneratorAction(),
  fParticleGun(nullptr),
  fDetectorConstruction(detCon)
{
    G4int nParticle = 1;
    fParticleGun = new G4ParticleGun(nParticle);
    
    G4ParticleTable* particleTable = G4ParticleTable::GetParticleTable();
    G4ParticleDefinition* particle = particleTable->FindParticle("gamma");
    fParticleGun->SetParticleDefinition(particle);
}

PrimaryGeneratorAction::~PrimaryGeneratorAction()
{
    delete fParticleGun;
}

void PrimaryGeneratorAction::GeneratePrimaries(G4Event* anEvent)
{
    GenerateCs137Spectrum(anEvent);
}

void PrimaryGeneratorAction::GenerateCs137Spectrum(G4Event* anEvent)
{
    G4LogicalVolume* waterLV = fDetectorConstruction->GetWaterVolume();
    
    if(!waterLV) {
        G4Exception("PrimaryGeneratorAction::GeneratePrimaries()",
                   "InvalidSetup", FatalException,
                   "Water volume not found!");
        return;
    }

    // Получаем параметры сосуда
    G4double wellTopZ = fDetectorConstruction->GetMarinelliWellTopZ();
    G4double wellBottomZ = fDetectorConstruction->GetMarinelliWellBottomZ();
    G4double waterTopZ = fDetectorConstruction->GetMarinelliWaterTopZ();
    G4double windowZ = fDetectorConstruction->GetWindowPositionZ();

    // Генерируем позицию в воде
    G4VSolid* waterSolid = waterLV->GetSolid();
    G4ThreeVector pos;
    G4int attempts = 0;
    const G4int maxAttempts = 1000;
    
    do {
        // Генерируем в ограничивающем объеме воды
        G4ThreeVector minBox, maxBox;
        waterSolid->BoundingLimits(minBox, maxBox);
        
        G4double x = minBox.x() + (maxBox.x()-minBox.x()) * G4UniformRand();
        G4double y = minBox.y() + (maxBox.y()-minBox.y()) * G4UniformRand();
        G4double z = wellBottomZ + (waterTopZ - wellBottomZ) * G4UniformRand();
        pos = G4ThreeVector(x,y,z);
        
        if(++attempts >= maxAttempts) {
            G4Exception("PrimaryGeneratorAction::GeneratePrimaries()",
                      "NoValidPosition", JustWarning,
                      "Could not find valid position in water volume!");
            break;
        }
    } while (waterSolid->Inside(pos) != kInside);

    // Направление к окну детектора
    G4ThreeVector windowPos(0, 0, windowZ);
    G4ThreeVector dir = (windowPos - pos).unit();

    // Добавляем небольшой разброс направлений
    G4double angleSpread = 5.0*deg;
    dir.rotateX(angleSpread*(G4UniformRand()-0.5));
    dir.rotateY(angleSpread*(G4UniformRand()-0.5));

    // Спектр Cs-137
    G4double energy = (G4UniformRand() < 0.85) ? 661.7*keV : 
                     (100*keV + 561.7*keV*G4UniformRand());
    
    fParticleGun->SetParticlePosition(pos);
    fParticleGun->SetParticleMomentumDirection(dir);
    fParticleGun->SetParticleEnergy(energy);
    fParticleGun->GeneratePrimaryVertex(anEvent);
}
