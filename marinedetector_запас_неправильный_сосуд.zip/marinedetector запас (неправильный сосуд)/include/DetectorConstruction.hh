#ifndef DETECTOR_CONSTRUCTION_HH
#define DETECTOR_CONSTRUCTION_HH

#include "G4VUserDetectorConstruction.hh"
#include "G4Material.hh"
#include "G4LogicalVolume.hh"
#include "G4SystemOfUnits.hh"
#include "globals.hh"

class DetectorConstruction : public G4VUserDetectorConstruction
{
public:
    DetectorConstruction();
    virtual ~DetectorConstruction();

    virtual G4VPhysicalVolume* Construct() override;
    virtual void ConstructSDandField() override;

    G4LogicalVolume* GetGermaniumVolume() const { return fLogicCrystal; }
    G4LogicalVolume* GetWaterVolume() const { return fLogicWater; }
    G4double GetMarinelliWellTopZ() const { return fMarinelliWellTopZ; }
    G4double GetMarinelliWellBottomZ() const { return fMarinelliWellBottomZ; }
    G4double GetMarinelliWaterTopZ() const { return fMarinelliWaterTopZ; }
    G4double GetWindowPositionZ() const { return fWindowPositionZ; }

private:
    void DefineMaterials();
    void ConstructGermaniumDetector();
    void ConstructMarinelliBeaker();
    void SetVisualAttributes();

    // Materials
    G4Material* fAir;
    G4Material* fVacuum;
    G4Material* fWater;
    G4Material* fGermanium;
    G4Material* fAluminum;
    G4Material* fBeryllium;
    G4Material* fCopper;
    G4Material* fKapton;
    G4Material* fPlastic;
    G4Material* fTeflon;
    G4Material* fStainlessSteel;

    // Logical volumes
    G4LogicalVolume* fLogicWorld;
    G4LogicalVolume* fLogicCrystal;
    G4LogicalVolume* fLogicDeadLayer;
    G4LogicalVolume* fLogicContact;
    G4LogicalVolume* fLogicWindow;
    G4LogicalVolume* fLogicVacuumGap;
    G4LogicalVolume* fLogicHousing;
    G4LogicalVolume* fLogicColdFinger;
    G4LogicalVolume* fLogicMountingFlange;
    G4LogicalVolume* fLogicEndCap;
    G4LogicalVolume* fLogicMarinelli;
    G4LogicalVolume* fLogicDetectorHousing;
    G4LogicalVolume* fLogicWater;

    // Positioning parameters
    G4double fMarinelliWellTopZ;
    G4double fMarinelliWellBottomZ;
    G4double fMarinelliWaterTopZ;
    G4double fWindowPositionZ;
};

#endif
