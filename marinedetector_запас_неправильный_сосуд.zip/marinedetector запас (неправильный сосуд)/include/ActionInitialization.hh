#ifndef ACTION_INITIALIZATION_HH
#define ACTION_INITIALIZATION_HH

#include "G4VUserActionInitialization.hh"

class DetectorConstruction;

class ActionInitialization : public G4VUserActionInitialization
{
public:
    ActionInitialization(DetectorConstruction* detCon);
    virtual ~ActionInitialization();

    virtual void Build() const override;
    virtual void BuildForMaster() const override;

private:
    DetectorConstruction* fDetectorConstruction;
};

#endif
