#include "ActionInitialization.hh"
#include "PrimaryGeneratorAction.hh"
#include "RunAction.hh"
#include "EventAction.hh"
#include "SteppingAction.hh"
#include "DetectorConstruction.hh"

ActionInitialization::ActionInitialization(DetectorConstruction* detCon)
 : G4VUserActionInitialization(),
   fDetectorConstruction(detCon)
{}

ActionInitialization::~ActionInitialization()
{}

void ActionInitialization::Build() const
{
    SetUserAction(new PrimaryGeneratorAction(fDetectorConstruction));
    
    RunAction* runAction = new RunAction();
    SetUserAction(runAction);
    
    EventAction* eventAction = new EventAction(runAction);
    SetUserAction(eventAction);
    
    SetUserAction(new SteppingAction(eventAction));
}

void ActionInitialization::BuildForMaster() const
{
    SetUserAction(new RunAction());
}
