#include "PrimaryGeneratorAction.hh"
#include "DetectorConstruction.hh"
#include "G4Event.hh"
#include "G4ParticleTable.hh"
#include "G4ParticleDefinition.hh"
#include "G4SystemOfUnits.hh"
#include "Randomize.hh"
#include "G4PhysicalConstants.hh"
#include "G4VSolid.hh"

PrimaryGeneratorAction::PrimaryGeneratorAction(DetectorConstruction* detCon)
: G4VUserPrimaryGeneratorAction(),
  fParticleGun(nullptr),
  fDetectorConstruction(detCon),
  fWaterSolid(nullptr)
{
    if(!fDetectorConstruction) {
        G4Exception("PrimaryGeneratorAction constructor", 
                  "InvalidSetup", FatalException,
                  "DetectorConstruction is null!");
    }

    G4int nParticle = 1;
    fParticleGun = new G4ParticleGun(nParticle);
    
    G4ParticleTable* particleTable = G4ParticleTable::GetParticleTable();
    G4ParticleDefinition* particle = particleTable->FindParticle("gamma");
    fParticleGun->SetParticleDefinition(particle);
}

PrimaryGeneratorAction::~PrimaryGeneratorAction()
{
    delete fParticleGun;
}

void PrimaryGeneratorAction::GeneratePrimaries(G4Event* anEvent)
{
    if(!fWaterSolid) {
        G4LogicalVolume* waterLV = fDetectorConstruction->GetWaterVolume();
        if(!waterLV) {
            G4Exception("PrimaryGeneratorAction::GeneratePrimaries()",
                       "InvalidSetup", FatalException,
                       "Water volume not found!");
            return;
        }
        fWaterSolid = waterLV->GetSolid();
    }
    
    GenerateCs137Spectrum(anEvent);
}

G4ThreeVector PrimaryGeneratorAction::SampleRandomPositionInWater() const
{
    if(!fWaterSolid) {
        G4Exception("PrimaryGeneratorAction::SampleRandomPositionInWater()",
                   "InvalidSetup", FatalException,
                   "Water solid not initialized!");
        return G4ThreeVector();
    }

    G4ThreeVector pos;
    G4int attempts = 0;
    const G4int maxAttempts = 10000;
    
    G4double waterMinZ = fDetectorConstruction->GetMarinelliWellBottomZ();
    G4double waterMaxZ = fDetectorConstruction->GetMarinelliWaterTopZ();
    G4double waterRadius = fDetectorConstruction->GetMarinelliOuterRadius() - 
                         fDetectorConstruction->GetMarinelliWallThickness();
    
    do {
        G4double r = waterRadius * std::sqrt(G4UniformRand());
        G4double phi = twopi * G4UniformRand();
        G4double z = waterMinZ + (waterMaxZ - waterMinZ) * G4UniformRand();
        
        pos = G4ThreeVector(r*cos(phi), r*sin(phi), z);
        
        if(++attempts >= maxAttempts) {
            G4Exception("PrimaryGeneratorAction::SampleRandomPositionInWater()",
                      "NoValidPosition", JustWarning,
                      "Could not find valid position in water volume!");
            break;
        }
    } while (fWaterSolid->Inside(pos) != kInside);

    return pos;
}

G4ThreeVector PrimaryGeneratorAction::SampleIsotropicDirection() const
{
    G4double cosTheta = 2.*G4UniformRand() - 1.;
    G4double sinTheta = std::sqrt(1. - cosTheta*cosTheta);
    G4double phi = twopi*G4UniformRand();
    
    return G4ThreeVector(sinTheta*std::cos(phi),
                        sinTheta*std::sin(phi),
                        cosTheta);
}

void PrimaryGeneratorAction::GenerateCs137Spectrum(G4Event* anEvent)
{
    G4ThreeVector pos = SampleRandomPositionInWater();
    G4ThreeVector dir = SampleIsotropicDirection();
    
    G4double energy = (G4UniformRand() < 0.85) ? 661.7*keV : 
                     (100*keV + 561.7*keV*G4UniformRand());
    
    fParticleGun->SetParticlePosition(pos);
    fParticleGun->SetParticleMomentumDirection(dir);
    fParticleGun->SetParticleEnergy(energy);
    fParticleGun->GeneratePrimaryVertex(anEvent);
}
