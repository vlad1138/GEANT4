#include "G4RunManager.hh"
#include "G4UImanager.hh"
#include "G4VisExecutive.hh"
#include "G4UIExecutive.hh"
#include "G4Types.hh"
#include <csignal>

#include "DetectorConstruction.hh"
#include "PhysicsList.hh"
#include "ActionInitialization.hh"

int main(int argc, char** argv)
{
    // Set up catch for segfaults
    signal(SIGSEGV, [](int) {
        G4cerr << "Segmentation fault detected!" << G4endl;
        std::abort();
    });

    try {
        // Create run manager (единственный экземпляр)
        auto* runManager = new G4RunManager;

        // Initialize mandatory user classes
        auto* detector = new DetectorConstruction();
        runManager->SetUserInitialization(detector);
        runManager->SetUserInitialization(new PhysicsList());
        runManager->SetUserInitialization(new ActionInitialization(detector));
        
        // Initialize G4 kernel (один раз)
        runManager->Initialize();

        // Visualization manager
        G4VisManager* visManager = nullptr;
        #ifdef G4VIS_USE
        visManager = new G4VisExecutive("quiet");
        visManager->Initialize();
        #endif

        // Get the pointer to the UI manager
        auto* UImanager = G4UImanager::GetUIpointer();

        // Batch mode or interactive mode
        if (argc == 1) {
            // Interactive mode with visualization
            #ifdef G4UI_USE
            auto* ui = new G4UIExecutive(argc, argv);
            
            // Basic visualization settings
            UImanager->ApplyCommand("/vis/scene/create");
            UImanager->ApplyCommand("/vis/open OGL 800x800-0+0");
            UImanager->ApplyCommand("/vis/viewer/set/viewpointThetaPhi 60 30");
            UImanager->ApplyCommand("/vis/viewer/set/style surface");
            UImanager->ApplyCommand("/vis/viewer/set/auxiliaryEdge true");
            UImanager->ApplyCommand("/vis/scene/add/trajectories smooth");
            UImanager->ApplyCommand("/vis/scene/add/axes 0 0 0 100 mm");
            
            // Advanced visualization settings
            UImanager->ApplyCommand("/vis/viewer/set/background white");
            UImanager->ApplyCommand("/vis/geometry/set/forceSolid all");
            UImanager->ApplyCommand("/vis/viewer/zoom 1.5");
            UImanager->ApplyCommand("/vis/viewer/set/projection perspective");
            
            ui->SessionStart();
            delete ui;
            #endif
        } else {
            // Batch mode
            G4String command = "/control/execute ";
            G4String fileName = argv[1];
            UImanager->ApplyCommand(command + fileName);
        }

        // Cleanup
        #ifdef G4VIS_USE
        delete visManager;
        #endif
        delete runManager;
        
    } catch (std::exception& e) {
        G4cerr << "Exception caught: " << e.what() << G4endl;
        return 1;
    } catch (...) {
        G4cerr << "Unknown exception caught!" << G4endl;
        return 1;
    }
std::cout << "Нажмите Enter для выхода...";
std::cin.get();
    return 0;
}
