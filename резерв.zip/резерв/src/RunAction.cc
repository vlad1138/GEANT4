#include "RunAction.hh"
#include "G4Run.hh"
#include "G4UnitsTable.hh"
#include "G4SystemOfUnits.hh"
#include "G4AnalysisManager.hh"
#include <fstream>
#include <iostream>

RunAction::RunAction()
: G4UserRunAction() {
    auto analysisManager = G4AnalysisManager::Instance();
    
    if (!analysisManager) {
        G4ExceptionDescription msg;
        msg << "Failed to create analysis manager";
        G4Exception("RunAction::RunAction()",
                   "Analysis_F000", FatalException, msg);
        return;
    }
    
    analysisManager->SetVerboseLevel(1);
    analysisManager->SetDefaultFileType("root");
    
    // Создаем гистограмму с более подходящими параметрами
    analysisManager->CreateH1("EnergyDeposit", "Energy deposition in detector", 
                            1000, 0., 3000., "keV");
    
    fTotalEnergyDeposit = 0.;
    fNumEvents = 0;
}

RunAction::~RunAction() {
    auto analysisManager = G4AnalysisManager::Instance();
    if (analysisManager && analysisManager->IsOpenFile()) {
        analysisManager->Write();
        analysisManager->CloseFile();
    }
}

void RunAction::BeginOfRunAction(const G4Run* run) {
    std::lock_guard<std::mutex> lock(fMutex);
    
    fEnergyDeposits.clear();
    fTotalEnergyDeposit = 0.;
    fNumEvents = 0;
    
    auto analysisManager = G4AnalysisManager::Instance();
    if (analysisManager) {
        G4String fileName = "analysis_" + std::to_string(run->GetRunID()) + ".root";
        if (!analysisManager->OpenFile(fileName)) {
            G4ExceptionDescription msg;
            msg << "Failed to open ROOT file: " << fileName;
            G4Exception("RunAction::BeginOfRunAction()",
                       "Analysis_F001", JustWarning, msg);
        }
    }
    
    G4cout << "### Run " << run->GetRunID() << " started." << G4endl;
}

void RunAction::EndOfRunAction(const G4Run* run) {
    std::lock_guard<std::mutex> lock(fMutex);
    
    auto analysisManager = G4AnalysisManager::Instance();
    if (analysisManager && analysisManager->IsOpenFile()) {
        analysisManager->Write();
        analysisManager->CloseFile();
    }
    
    // Сохранение спектра в текстовый файл
    std::ofstream spectrumFile("spectrum_" + std::to_string(run->GetRunID()) + ".dat");
    if (spectrumFile.is_open()) {
        for (G4double edep : fEnergyDeposits) {
            spectrumFile << edep/keV << "\n";
        }
        spectrumFile.close();
    }
    
    // Расчет эффективности
    G4int numDetected = fEnergyDeposits.size();
    G4int totalEvents = run->GetNumberOfEvent();
    G4double efficiency = totalEvents > 0 ? (G4double)numDetected / totalEvents : 0.;
    
    // Вывод статистики
    G4cout << "\n--- Run summary ---\n"
           << " Events processed: " << totalEvents << "\n"
           << " Detected events: " << numDetected << "\n"
           << " Efficiency: " << efficiency*100 << "%\n"
           << " Total energy: " << G4BestUnit(fTotalEnergyDeposit, "Energy") 
           << G4endl;
}

void RunAction::AddEnergyDeposit(G4double edep) {
    std::lock_guard<std::mutex> lock(fMutex);
    
    fEnergyDeposits.push_back(edep);
    fTotalEnergyDeposit.store(fTotalEnergyDeposit.load() + edep);
    fNumEvents++;
}
