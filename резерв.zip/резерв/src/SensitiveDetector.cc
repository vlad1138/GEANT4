#include "SensitiveDetector.hh"
#include "G4Step.hh"
#include "G4TouchableHistory.hh"
#include "G4Track.hh"
#include "G4AnalysisManager.hh"

SensitiveDetector::SensitiveDetector(G4String name) 
: G4VSensitiveDetector(name) {}

SensitiveDetector::~SensitiveDetector() {}

void SensitiveDetector::Initialize(G4HCofThisEvent*) {
    // Инициализация при необходимости
}

G4bool SensitiveDetector::ProcessHits(G4Step* step, G4TouchableHistory*) {
    G4Track* track = step->GetTrack();
    
    // Регистрируем только гамма-кванты
    if(track->GetDefinition()->GetParticleName() != "gamma") return true;
    
    // Получаем энергию депозита
    G4double edep = step->GetTotalEnergyDeposit();
    if(edep == 0.) return false;
    
    // Записываем энергию в гистограмму
    auto analysisManager = G4AnalysisManager::Instance();
    analysisManager->FillH1(0, edep);
    
    return true;
}
