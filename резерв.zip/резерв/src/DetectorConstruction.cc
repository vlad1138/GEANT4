#include "DetectorConstruction.hh"
#include "G4NistManager.hh"
#include "G4Box.hh"
#include "G4Tubs.hh"
#include "G4Cons.hh"
#include "G4LogicalVolume.hh"
#include "G4PVPlacement.hh"
#include "G4SystemOfUnits.hh"
#include "G4VisAttributes.hh"
#include "G4SubtractionSolid.hh"
#include "G4UnionSolid.hh"
#include "G4SDManager.hh"
#include "G4Colour.hh"
#include "SensitiveDetector.hh"

DetectorConstruction::DetectorConstruction() 
: fWallThickness(3.0*mm),
  fMarinelliWellTopZ(0),
  fMarinelliWellBottomZ(0),
  fMarinelliWaterTopZ(0),
  fWindowPositionZ(0)
{
    // Инициализация всех указателей
    fLogic.World = nullptr;
    fLogic.Crystal = nullptr;
    fLogic.DeadLayer = nullptr;
    fLogic.Contact = nullptr;
    fLogic.Window = nullptr;
    fLogic.VacuumGap = nullptr;
    fLogic.Housing = nullptr;
    fLogic.ColdFinger = nullptr;
    fLogic.MountingFlange = nullptr;
    fLogic.EndCap = nullptr;
    fLogic.Marinelli = nullptr;
    fLogic.Water = nullptr;
    
    DefineMaterials();
}

void DetectorConstruction::DefineMaterials()
{
    G4NistManager* nist = G4NistManager::Instance();
    
    fAir = nist->FindOrBuildMaterial("G4_AIR");
    fVacuum = nist->FindOrBuildMaterial("G4_Galactic");
    fWater = nist->FindOrBuildMaterial("G4_WATER");
    fGermanium = nist->FindOrBuildMaterial("G4_Ge");
    fAluminum = nist->FindOrBuildMaterial("G4_Al");
    fBeryllium = nist->FindOrBuildMaterial("G4_Be");
    fCopper = nist->FindOrBuildMaterial("G4_Cu");
    fPlastic = nist->FindOrBuildMaterial("G4_PLEXIGLASS");
    fStainlessSteel = nist->FindOrBuildMaterial("G4_STAINLESS-STEEL");
    
    fKapton = new G4Material("Kapton", 1.42*g/cm3, 3);
    fKapton->AddElement(nist->FindOrBuildElement("C"), 22);
    fKapton->AddElement(nist->FindOrBuildElement("H"), 10);
    fKapton->AddElement(nist->FindOrBuildElement("O"), 5);
    
    fTeflon = new G4Material("Teflon", 2.2*g/cm3, 2);
    fTeflon->AddElement(nist->FindOrBuildElement("C"), 2);
    fTeflon->AddElement(nist->FindOrBuildElement("F"), 4);
}

void DetectorConstruction::ConstructGermaniumDetector()
{
    // ORTEC GEM60-P4 параметры
    G4double crystalDiam = 60.5*mm;
    G4double crystalHeight = 54.5*mm;
    G4double holeDiam = 10.0*mm;
    G4double holeDepth = 42.0*mm;
    G4double deadLayerThickness = 0.7*mm;
    G4double contactThickness = 0.1*mm;
    G4double windowThickness = 0.5*mm;
    G4double vacuumGap = 1.0*mm;
    G4double housingThickness = 3.0*mm;
    G4double housingLength = 80.0*mm;
    G4double coldFingerDiam = 8.0*mm;
    G4double coldFingerLength = 30.0*mm;
    G4double endCapThickness = 1.5*mm;
    G4double flangeThickness = 5.0*mm;
    G4double flangeDiam = 76.0*mm;

    // Germanium crystal with hole
    G4Tubs* solidCrystalOuter = new G4Tubs("CrystalOuter", 0, crystalDiam/2, crystalHeight/2, 0, 360*deg);
    G4Tubs* solidHole = new G4Tubs("Hole", 0, holeDiam/2, holeDepth/2, 0, 360*deg);
    G4SubtractionSolid* solidCrystal = new G4SubtractionSolid("Crystal", solidCrystalOuter, solidHole,
                                                            0, G4ThreeVector(0,0,crystalHeight/2-holeDepth/2));
    fLogic.Crystal = new G4LogicalVolume(solidCrystal, fGermanium, "Crystal");

    // Dead layer (outer surface)
    G4Tubs* solidDeadLayer = new G4Tubs("DeadLayer", 
                                      crystalDiam/2 - deadLayerThickness, 
                                      crystalDiam/2, 
                                      crystalHeight/2, 
                                      0, 360*deg);
    fLogic.DeadLayer = new G4LogicalVolume(solidDeadLayer, fGermanium, "DeadLayer");

    // Electrical contact (outer surface)
    G4Tubs* solidContact = new G4Tubs("Contact", 
                                    crystalDiam/2, 
                                    crystalDiam/2 + contactThickness, 
                                    crystalHeight/2, 
                                    0, 360*deg);
    fLogic.Contact = new G4LogicalVolume(solidContact, fAluminum, "Contact");

    // Vacuum gap
    G4Tubs* solidVacuumGap = new G4Tubs("VacuumGap", 
                                      crystalDiam/2 + contactThickness, 
                                      crystalDiam/2 + contactThickness + vacuumGap, 
                                      crystalHeight/2, 
                                      0, 360*deg);
    fLogic.VacuumGap = new G4LogicalVolume(solidVacuumGap, fVacuum, "VacuumGap");

    // Aluminum housing
    G4Tubs* solidHousing = new G4Tubs("Housing", 
                                    0, 
                                    crystalDiam/2 + contactThickness + vacuumGap + housingThickness, 
                                    housingLength/2, 
                                    0, 360*deg);
    fLogic.Housing = new G4LogicalVolume(solidHousing, fAluminum, "Housing");

    // Cold finger (copper)
    G4Tubs* solidColdFinger = new G4Tubs("ColdFinger", 0, coldFingerDiam/2, coldFingerLength/2, 0, 360*deg);
    fLogic.ColdFinger = new G4LogicalVolume(solidColdFinger, fCopper, "ColdFinger");

    // Mounting flange (stainless steel)
    G4Tubs* solidFlange = new G4Tubs("Flange", 0, flangeDiam/2, flangeThickness/2, 0, 360*deg);
    fLogic.MountingFlange = new G4LogicalVolume(solidFlange, fStainlessSteel, "Flange");

    // End cap with Be window
    G4Tubs* solidEndCap = new G4Tubs("EndCap", 
                                   0, 
                                   crystalDiam/2 + contactThickness + vacuumGap + housingThickness, 
                                   endCapThickness/2, 
                                   0, 360*deg);
    G4Tubs* solidWindow = new G4Tubs("Window", 0, crystalDiam/2, windowThickness/2, 0, 360*deg);
    G4SubtractionSolid* solidEndCapWithWindow = new G4SubtractionSolid("EndCapWithWindow", solidEndCap, solidWindow,
                                                                     0, G4ThreeVector(0,0,-endCapThickness/2+windowThickness/2));
    fLogic.EndCap = new G4LogicalVolume(solidEndCapWithWindow, fAluminum, "EndCap");
    fLogic.Window = new G4LogicalVolume(solidWindow, fBeryllium, "Window");

    // Assembly
    G4double zPos = -housingLength/2 + endCapThickness/2;
    new G4PVPlacement(0, G4ThreeVector(0,0,zPos), fLogic.EndCap, "EndCap", fLogic.Housing, false, 0);
    
    zPos += endCapThickness/2 + windowThickness/2;
    new G4PVPlacement(0, G4ThreeVector(0,0,zPos), fLogic.Window, "Window", fLogic.Housing, false, 0);
    
    zPos += windowThickness/2 + crystalHeight/2;
    new G4PVPlacement(0, G4ThreeVector(0,0,zPos), fLogic.Crystal, "Crystal", fLogic.Housing, false, 0);
    new G4PVPlacement(0, G4ThreeVector(0,0,zPos), fLogic.DeadLayer, "DeadLayer", fLogic.Housing, false, 1);
    new G4PVPlacement(0, G4ThreeVector(0,0,zPos), fLogic.Contact, "Contact", fLogic.Housing, false, 2);
    new G4PVPlacement(0, G4ThreeVector(0,0,zPos), fLogic.VacuumGap, "VacuumGap", fLogic.Housing, false, 3);
    
    zPos = housingLength/2 - coldFingerLength/2;
    new G4PVPlacement(0, G4ThreeVector(0,0,zPos), fLogic.ColdFinger, "ColdFinger", fLogic.Housing, false, 0);
    
    zPos = housingLength/2 + flangeThickness/2;
    new G4PVPlacement(0, G4ThreeVector(0,0,zPos), fLogic.MountingFlange, "Flange", fLogic.Housing, false, 0);

    // Запоминаем позицию окна детектора
    fWindowPositionZ = zPos - flangeThickness/2 - housingLength/2 + endCapThickness + windowThickness;
}

void DetectorConstruction::ConstructMarinelliBeaker()
{
    G4double outerRadius = GetMarinelliOuterRadius();
    G4double totalHeight = GetMarinelliTotalHeight();
    G4double bottomThickness = GetMarinelliBottomThickness();
    G4double wellHeight = GetMarinelliWellHeight();
    G4double wellOuterRadius = GetMarinelliWellRadius();
    G4double wellInnerRadius = wellOuterRadius - fWallThickness;

    // Создание твердотельных моделей
    G4Tubs* solidOuter = new G4Tubs("Outer", 0, outerRadius, totalHeight/2, 0, 360*deg);
    G4Tubs* solidInner = new G4Tubs("Inner", 0, outerRadius - fWallThickness, 
                                   (totalHeight - bottomThickness)/2, 0, 360*deg);
    G4Tubs* solidWell = new G4Tubs("Well", 0, wellOuterRadius, wellHeight/2, 0, 360*deg);
    G4Tubs* solidHole = new G4Tubs("Hole", 0, wellOuterRadius, fWallThickness, 0, 360*deg);

    // Сборка сосуда Маринелли
    G4SubtractionSolid* solidBody = new G4SubtractionSolid("Body", solidOuter, solidInner, 0, G4ThreeVector());
    
    G4double wellZ = totalHeight/2 - wellHeight/2;
    G4UnionSolid* solidWithWell = new G4UnionSolid("WithWell", solidBody, solidWell,
                                                 0, G4ThreeVector(0, 0, wellZ));
    
    G4double holeZ = totalHeight/2 - fWallThickness/2;
    G4SubtractionSolid* solidBeaker = new G4SubtractionSolid("Beaker", solidWithWell, solidHole,
                                                          0, G4ThreeVector(0, 0, holeZ));

    // Создание водного объема
    G4SubtractionSolid* solidWater = new G4SubtractionSolid("Water", solidInner, solidWell,
                                                         0, G4ThreeVector(0, 0, wellZ));

    // Создание логических объемов
    fLogic.Marinelli = new G4LogicalVolume(solidBeaker, fPlastic, "MarinelliBeaker");
    fLogic.Water = new G4LogicalVolume(solidWater, fWater, "MarinelliWater");

    // Сохранение параметров геометрии
    fMarinelliWellTopZ = wellZ - wellHeight/2;
    fMarinelliWellBottomZ = wellZ + wellHeight/2;
    fMarinelliWaterTopZ = (totalHeight - bottomThickness)/2;
}

G4VPhysicalVolume* DetectorConstruction::Construct()
{
    // World volume
    G4Box* solidWorld = new G4Box("World", 1*m, 1*m, 1*m);
    fLogic.World = new G4LogicalVolume(solidWorld, fAir, "World");
    G4PVPlacement* physWorld = new G4PVPlacement(0, G4ThreeVector(), fLogic.World, "World", 0, false, 0);

    // Построение детекторов
    ConstructGermaniumDetector();
    ConstructMarinelliBeaker();

    // Проверка инициализации
    if(!fLogic.Water || !fLogic.Marinelli) {
        G4Exception("DetectorConstruction::Construct()",
                   "InvalidSetup", FatalException,
                   "Critical volumes not properly constructed!");
    }

    // Позиционирование детектора
    G4double detectorPosZ = 0;
    new G4PVPlacement(0, G4ThreeVector(0,0,detectorPosZ),
                    fLogic.Housing, "Detector", fLogic.World, false, 0, true);

    // Позиционирование сосуда Маринелли с большим зазором
    G4double detectorHeight = 80.0*mm;
    G4double marinelliZ = detectorPosZ - detectorHeight/2 - GetMarinelliTotalHeight()/2 - 20.0*mm;
    
    new G4PVPlacement(0, G4ThreeVector(0,0,marinelliZ),
                    fLogic.Marinelli, "MarinelliBeaker", fLogic.World, false, 0, true);
    
    new G4PVPlacement(0, G4ThreeVector(0,0,marinelliZ),
                    fLogic.Water, "MarinelliWater", fLogic.World, false, 0, true);

    SetVisualAttributes();
    return physWorld;
}

void DetectorConstruction::ConstructSDandField()
{
    G4SDManager* SDman = G4SDManager::GetSDMpointer();
    G4String SDname = "GermaniumSD";
    SensitiveDetector* germaniumSD = new SensitiveDetector(SDname);
    SDman->AddNewDetector(germaniumSD);
    fLogic.Crystal->SetSensitiveDetector(germaniumSD);
}

void DetectorConstruction::SetVisualAttributes()
{
    // Делаем мировой объем полностью прозрачным и невидимым
    G4VisAttributes* worldVisAttr = new G4VisAttributes(G4Colour(1.0, 1.0, 1.0, 0.0));
    worldVisAttr->SetVisibility(false);
    fLogic.World->SetVisAttributes(worldVisAttr);

    G4VisAttributes* visAttr;
    
    // Germanium crystal (полупрозрачный серый)
    visAttr = new G4VisAttributes(G4Colour(0.7, 0.7, 0.7, 0.7));
    visAttr->SetForceSolid(true);
    fLogic.Crystal->SetVisAttributes(visAttr);
    
    // Dead layer (красный, полупрозрачный)
    visAttr = new G4VisAttributes(G4Colour(1.0, 0.0, 0.0, 0.3));
    visAttr->SetForceSolid(true);
    fLogic.DeadLayer->SetVisAttributes(visAttr);
    
    // Contact (металлик)
    visAttr = new G4VisAttributes(G4Colour(0.9, 0.9, 0.9));
    visAttr->SetForceSolid(true);
    fLogic.Contact->SetVisAttributes(visAttr);
    
    // Vacuum gap (невидимый)
    visAttr = new G4VisAttributes(G4Colour(0,0,0,0));
    visAttr->SetVisibility(false);
    fLogic.VacuumGap->SetVisAttributes(visAttr);
    
    // Housing (только каркас)
    visAttr = new G4VisAttributes(G4Colour(0.8, 0.8, 0.8));
    visAttr->SetForceWireframe(true);
    fLogic.Housing->SetVisAttributes(visAttr);
    
    // Cold finger (медный)
    visAttr = new G4VisAttributes(G4Colour(0.8, 0.5, 0.2));
    visAttr->SetForceSolid(true);
    fLogic.ColdFinger->SetVisAttributes(visAttr);
    
    // Be window (зеленый, полупрозрачный)
    visAttr = new G4VisAttributes(G4Colour(0.0, 1.0, 0.0, 0.7));
    visAttr->SetForceSolid(true);
    fLogic.Window->SetVisAttributes(visAttr);
    
    // Marinelli beaker (синий пластик, полупрозрачный)
    visAttr = new G4VisAttributes(G4Colour(0.0, 0.5, 1.0, 0.5));
    visAttr->SetForceSolid(true);
    fLogic.Marinelli->SetVisAttributes(visAttr);
    
    // Water (голубая, полупрозрачная)
    visAttr = new G4VisAttributes(G4Colour(0.0, 0.8, 1.0, 0.4));
    visAttr->SetForceSolid(true);
    fLogic.Water->SetVisAttributes(visAttr);
    
    // Mounting flange (стальной)
    visAttr = new G4VisAttributes(G4Colour(0.5, 0.5, 0.5));
    visAttr->SetForceSolid(true);
    fLogic.MountingFlange->SetVisAttributes(visAttr);
}

G4LogicalVolume* DetectorConstruction::GetGermaniumVolume() const 
{
    if(!fLogic.Crystal) {
        G4ExceptionDescription msg;
        msg << "Germanium crystal volume is not initialized!";
        G4Exception("DetectorConstruction::GetGermaniumVolume()",
                   "InvalidSetup", FatalException, msg);
    }
    return fLogic.Crystal;
}

G4LogicalVolume* DetectorConstruction::GetWaterVolume() const
{
    if(!fLogic.Water) {
        G4ExceptionDescription msg;
        msg << "Water volume is not initialized!";
        G4Exception("DetectorConstruction::GetWaterVolume()",
                   "InvalidSetup", FatalException, msg);
    }
    return fLogic.Water;
}

DetectorConstruction::~DetectorConstruction()
{
    // Деструктор может быть пустым, так как Geant4 управляет памятью
}
