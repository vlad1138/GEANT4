#ifndef RUN_ACTION_HH
#define RUN_ACTION_HH
#include <atomic>
#include "G4UserRunAction.hh"
#include "globals.hh"
#include <vector>
#include <mutex>

class RunAction : public G4UserRunAction {
public:
    RunAction();
    virtual ~RunAction();
    
    virtual void BeginOfRunAction(const G4Run*) override;
    virtual void EndOfRunAction(const G4Run*) override;
    
    void AddEnergyDeposit(G4double edep);
    
private:
    std::vector<G4double> fEnergyDeposits;
    std::atomic<G4double> fTotalEnergyDeposit;  
    std::atomic<G4int> fNumEvents;
    std::mutex fMutex;  // Для потокобезопасности в MT-режиме
};

#endif
