#ifndef DETECTOR_CONSTRUCTION_HH
#define DETECTOR_CONSTRUCTION_HH

#include "G4VUserDetectorConstruction.hh"
#include "G4Material.hh"
#include "G4LogicalVolume.hh"
#include "G4SystemOfUnits.hh"
#include "globals.hh"

class G4VPhysicalVolume;
class G4VSensitiveDetector;

class DetectorConstruction : public G4VUserDetectorConstruction
{
public:
    DetectorConstruction();
    virtual ~DetectorConstruction();

    virtual G4VPhysicalVolume* Construct() override;
    virtual void ConstructSDandField() override;

    G4LogicalVolume* GetGermaniumVolume() const;
    G4LogicalVolume* GetWaterVolume() const;
    
    G4double GetMarinelliWellTopZ() const { return fMarinelliWellTopZ; }
    G4double GetMarinelliWellBottomZ() const { return fMarinelliWellBottomZ; }
    G4double GetMarinelliWallThickness() const { return fWallThickness; }
    G4double GetMarinelliWaterTopZ() const { return fMarinelliWaterTopZ; }
    G4double GetWindowPositionZ() const { return fWindowPositionZ; }
    
    static constexpr G4double GetMarinelliOuterRadius() { return 85.0*mm; }
    static constexpr G4double GetMarinelliWellRadius() { return 45.0*mm; }
    static constexpr G4double GetMarinelliTotalHeight() { return 130.0*mm; }
    static constexpr G4double GetMarinelliBottomThickness() { return 5.0*mm; }
    static constexpr G4double GetMarinelliWellHeight() { return 71.0*mm; }

private:
    void DefineMaterials();
    void ConstructGermaniumDetector();
    void ConstructMarinelliBeaker();
    void SetVisualAttributes();

    // Materials
    G4Material* fAir;
    G4Material* fVacuum;
    G4Material* fWater;
    G4Material* fGermanium;
    G4Material* fAluminum;
    G4Material* fBeryllium;
    G4Material* fCopper;
    G4Material* fKapton;
    G4Material* fPlastic;
    G4Material* fTeflon;
    G4Material* fStainlessSteel;

    // Logical volumes
    struct {
        G4LogicalVolume* World;
        G4LogicalVolume* Crystal;
        G4LogicalVolume* DeadLayer;
        G4LogicalVolume* Contact;
        G4LogicalVolume* Window;
        G4LogicalVolume* VacuumGap;
        G4LogicalVolume* Housing;
        G4LogicalVolume* ColdFinger;
        G4LogicalVolume* MountingFlange;
        G4LogicalVolume* EndCap;
        G4LogicalVolume* Marinelli;
        G4LogicalVolume* Water;
    } fLogic;

    // Geometry parameters
    G4double fWallThickness;
    G4double fMarinelliWellTopZ;
    G4double fMarinelliWellBottomZ;
    G4double fMarinelliWaterTopZ;
    G4double fWindowPositionZ;
};

#endif
